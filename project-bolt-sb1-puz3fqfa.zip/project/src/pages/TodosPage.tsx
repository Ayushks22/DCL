import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Layout from '../components/layout/Layout';
import TodoList from '../components/todo/TodoList';
import { Todo } from '../types';

// Mock data
const mockTodos: Todo[] = [
  {
    id: '1',
    userId: 'user1',
    title: 'Finish project proposal',
    isCompleted: false,
    dueDate: new Date(),
    priority: 'high',
    createdAt: new Date()
  },
  {
    id: '2',
    userId: 'user1',
    title: 'Call dentist',
    isCompleted: true,
    priority: 'medium',
    createdAt: new Date()
  },
  {
    id: '3',
    userId: 'user1',
    title: 'Go grocery shopping',
    isCompleted: false,
    dueDate: new Date(Date.now() + 86400000),
    priority: 'low',
    createdAt: new Date()
  },
  {
    id: '4',
    userId: 'user1',
    title: 'Schedule team meeting',
    isCompleted: false,
    priority: 'medium',
    createdAt: new Date()
  }
];

const TodosPage: React.FC = () => {
  const [todos, setTodos] = useState<Todo[]>(mockTodos);
  const [loading, setLoading] = useState(false);

  const handleAddTodo = (newTodo: Omit<Todo, 'id' | 'userId' | 'createdAt'>) => {
    const todo: Todo = {
      ...newTodo,
      id: Date.now().toString(),
      userId: 'user1',
      createdAt: new Date()
    };
    
    setTodos([...todos, todo]);
  };

  const handleToggleTodo = (todoId: string) => {
    setTodos(prevTodos => 
      prevTodos.map(todo => 
        todo.id === todoId 
          ? { ...todo, isCompleted: !todo.isCompleted } 
          : todo
      )
    );
  };

  const handleDeleteTodo = (todoId: string) => {
    setTodos(prevTodos => prevTodos.filter(todo => todo.id !== todoId));
  };

  // Filter todos by priority
  const highPriorityTodos = todos.filter(todo => todo.priority === 'high' && !todo.isCompleted);
  const otherTodos = todos.filter(todo => todo.priority !== 'high' && !todo.isCompleted);
  const completedTodos = todos.filter(todo => todo.isCompleted);

  return (
    <Layout title="To-Do List">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* High Priority Todos */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="md:col-span-3"
        >
          <div className="bg-white dark:bg-gray-800 rounded-xl p-4 sm:p-6 shadow-sm border border-gray-100 dark:border-gray-700">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center">
                <span className="h-3 w-3 bg-red-500 rounded-full mr-2"></span>
                High Priority
              </h2>
            </div>

            {highPriorityTodos.length === 0 ? (
              <p className="text-gray-500 dark:text-gray-400 py-4">No high priority tasks</p>
            ) : (
              <div className="space-y-2">
                {highPriorityTodos.map(todo => (
                  <TodoItem
                    key={todo.id}
                    todo={todo}
                    onToggle={handleToggleTodo}
                    onDelete={handleDeleteTodo}
                  />
                ))}
              </div>
            )}
          </div>
        </motion.div>

        {/* Full TodoList */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
          className="md:col-span-3"
        >
          <TodoList
            todos={todos}
            loading={loading}
            onAddTodo={handleAddTodo}
            onToggleTodo={handleToggleTodo}
            onDeleteTodo={handleDeleteTodo}
          />
        </motion.div>
      </div>
    </Layout>
  );
};

// Simple version of TodoItem for this page
const TodoItem: React.FC<{
  todo: Todo;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
}> = ({ todo, onToggle, onDelete }) => {
  return (
    <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
      <div className="flex items-center">
        <input
          type="checkbox"
          checked={todo.isCompleted}
          onChange={() => onToggle(todo.id)}
          className="h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
        />
        <span className={`ml-3 ${todo.isCompleted ? 'line-through text-gray-500' : 'text-gray-900 dark:text-white'}`}>
          {todo.title}
        </span>
      </div>
      
      <div className="flex items-center">
        {todo.dueDate && (
          <span className="text-xs text-gray-500 dark:text-gray-400 mr-2">
            Due: {new Date(todo.dueDate).toLocaleDateString()}
          </span>
        )}
        <button
          onClick={() => onDelete(todo.id)}
          className="text-gray-400 hover:text-red-500"
        >
          &times;
        </button>
      </div>
    </div>
  );
};

export default TodosPage;