import React, { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { motion } from 'framer-motion';
import Layout from '../components/layout/Layout';
import HabitList from '../components/checklist/HabitList';
import TodoList from '../components/todo/TodoList';
import ProgressChart from '../components/reports/ProgressChart';
import Calendar from '../components/calendar/Calendar';
import { Habit, Todo, DailyRecord } from '../types';

// Mock data for development
const mockHabits: Habit[] = [
  {
    id: '1',
    userId: 'user1',
    title: 'Drink 8 glasses of water',
    description: 'Stay hydrated throughout the day',
    isCompleted: false,
    createdAt: new Date(),
    frequency: 'daily',
    category: 'Health',
    streak: 5
  },
  {
    id: '2',
    userId: 'user1',
    title: 'Read for 30 minutes',
    isCompleted: true,
    completedAt: new Date(),
    createdAt: new Date(),
    frequency: 'daily',
    category: 'Personal Development',
    streak: 12
  },
  {
    id: '3',
    userId: 'user1',
    title: 'Meditate',
    isCompleted: false,
    createdAt: new Date(),
    frequency: 'daily',
    category: 'Mindfulness',
    streak: 3
  }
];

const mockTodos: Todo[] = [
  {
    id: '1',
    userId: 'user1',
    title: 'Finish project proposal',
    isCompleted: false,
    dueDate: new Date(),
    priority: 'high',
    createdAt: new Date()
  },
  {
    id: '2',
    userId: 'user1',
    title: 'Call dentist',
    isCompleted: true,
    priority: 'medium',
    createdAt: new Date()
  }
];

const mockRecords: DailyRecord[] = [
  {
    id: '1',
    userId: 'user1',
    date: new Date(),
    completedHabits: ['2'],
    totalHabits: 3
  },
  {
    id: '2',
    userId: 'user1',
    date: new Date(Date.now() - 86400000),
    completedHabits: ['1', '2', '3'],
    totalHabits: 3
  },
  {
    id: '3',
    userId: 'user1',
    date: new Date(Date.now() - 172800000),
    completedHabits: ['1', '2'],
    totalHabits: 3
  }
];

const DashboardPage: React.FC = () => {
  const [habits, setHabits] = useState<Habit[]>(mockHabits);
  const [todos, setTodos] = useState<Todo[]>(mockTodos);
  const [records, setRecords] = useState<DailyRecord[]>(mockRecords);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [loading, setLoading] = useState(false);
  
  const currentDateString = format(new Date(), 'EEEE, MMMM d');

  const handleAddHabit = (newHabit: Omit<Habit, 'id' | 'userId' | 'createdAt' | 'streak'>) => {
    const habit: Habit = {
      ...newHabit,
      id: Date.now().toString(),
      userId: 'user1',
      createdAt: new Date(),
      streak: 0
    };
    
    setHabits([...habits, habit]);
  };

  const handleToggleHabit = (habitId: string) => {
    setHabits(prevHabits => 
      prevHabits.map(habit => 
        habit.id === habitId 
          ? { 
              ...habit, 
              isCompleted: !habit.isCompleted,
              completedAt: !habit.isCompleted ? new Date() : undefined,
              streak: !habit.isCompleted ? habit.streak + 1 : Math.max(0, habit.streak - 1)
            } 
          : habit
      )
    );
    
    // Update records
    const today = new Date();
    const todayRecord = records.find(r => format(new Date(r.date), 'yyyy-MM-dd') === format(today, 'yyyy-MM-dd'));
    
    if (todayRecord) {
      const habit = habits.find(h => h.id === habitId);
      let completedHabits = [...todayRecord.completedHabits];
      
      if (habit && !habit.isCompleted) {
        // Add to completed
        if (!completedHabits.includes(habitId)) {
          completedHabits.push(habitId);
        }
      } else {
        // Remove from completed
        completedHabits = completedHabits.filter(id => id !== habitId);
      }
      
      setRecords(prevRecords => 
        prevRecords.map(r => 
          r.id === todayRecord.id 
            ? { ...r, completedHabits } 
            : r
        )
      );
    } else {
      // Create new record for today
      const habit = habits.find(h => h.id === habitId);
      const newRecord: DailyRecord = {
        id: Date.now().toString(),
        userId: 'user1',
        date: today,
        completedHabits: habit && !habit.isCompleted ? [habitId] : [],
        totalHabits: habits.length
      };
      
      setRecords([...records, newRecord]);
    }
  };

  const handleDeleteHabit = (habitId: string) => {
    setHabits(prevHabits => prevHabits.filter(habit => habit.id !== habitId));
    
    // Update records
    setRecords(prevRecords => 
      prevRecords.map(record => ({
        ...record,
        completedHabits: record.completedHabits.filter(id => id !== habitId),
        totalHabits: record.totalHabits - 1
      }))
    );
  };

  const handleAddTodo = (newTodo: Omit<Todo, 'id' | 'userId' | 'createdAt'>) => {
    const todo: Todo = {
      ...newTodo,
      id: Date.now().toString(),
      userId: 'user1',
      createdAt: new Date()
    };
    
    setTodos([...todos, todo]);
  };

  const handleToggleTodo = (todoId: string) => {
    setTodos(prevTodos => 
      prevTodos.map(todo => 
        todo.id === todoId 
          ? { ...todo, isCompleted: !todo.isCompleted } 
          : todo
      )
    );
  };

  const handleDeleteTodo = (todoId: string) => {
    setTodos(prevTodos => prevTodos.filter(todo => todo.id !== todoId));
  };

  return (
    <Layout>
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Dashboard</h1>
        <p className="text-gray-600 dark:text-gray-300 mt-1">{currentDateString}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content - Habits and Todos */}
        <div className="lg:col-span-2 space-y-6">
          {/* Habits */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <HabitList
              habits={habits}
              loading={loading}
              onAddHabit={handleAddHabit}
              onToggleHabit={handleToggleHabit}
              onDeleteHabit={handleDeleteHabit}
            />
          </motion.div>

          {/* Todo List */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <TodoList
              todos={todos}
              loading={loading}
              onAddTodo={handleAddTodo}
              onToggleTodo={handleToggleTodo}
              onDeleteTodo={handleDeleteTodo}
            />
          </motion.div>
        </div>

        {/* Sidebar - Calendar and Progress */}
        <div className="space-y-6">
          {/* Progress Chart */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <ProgressChart records={records} />
          </motion.div>

          {/* Calendar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <Calendar
              records={records}
              onSelectDate={setSelectedDate}
              selectedDate={selectedDate}
            />
          </motion.div>
        </div>
      </div>
    </Layout>
  );
};

export default DashboardPage;