import React, { useState, useEffect } from 'react';
import { format } from 'date-fns';
import Layout from '../components/layout/Layout';
import Calendar from '../components/calendar/Calendar';
import HabitList from '../components/checklist/HabitList';
import { Habit, DailyRecord } from '../types';

// Mock data
const mockHabits: Habit[] = [
  {
    id: '1',
    userId: 'user1',
    title: 'Drink 8 glasses of water',
    description: 'Stay hydrated throughout the day',
    isCompleted: true,
    completedAt: new Date(),
    createdAt: new Date(),
    frequency: 'daily',
    category: 'Health',
    streak: 5
  },
  {
    id: '2',
    userId: 'user1',
    title: 'Read for 30 minutes',
    isCompleted: false,
    createdAt: new Date(),
    frequency: 'daily',
    category: 'Personal Development',
    streak: 12
  },
  {
    id: '3',
    userId: 'user1',
    title: 'Meditate',
    isCompleted: true,
    completedAt: new Date(),
    createdAt: new Date(),
    frequency: 'daily',
    category: 'Mindfulness',
    streak: 3
  }
];

const mockRecords: DailyRecord[] = [
  {
    id: '1',
    userId: 'user1',
    date: new Date(),
    completedHabits: ['1', '3'],
    totalHabits: 3
  },
  {
    id: '2',
    userId: 'user1',
    date: new Date(Date.now() - 86400000),
    completedHabits: ['1', '2', '3'],
    totalHabits: 3
  }
];

const CalendarPage: React.FC = () => {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [records, setRecords] = useState<DailyRecord[]>(mockRecords);
  const [habits, setHabits] = useState<Habit[]>(mockHabits);
  const [loading, setLoading] = useState(false);
  
  const formattedDate = format(selectedDate, 'MMMM d, yyyy');
  
  // Filter habits based on selected date
  const selectedDateRecord = records.find(record => 
    format(new Date(record.date), 'yyyy-MM-dd') === format(selectedDate, 'yyyy-MM-dd')
  );
  
  // If we have a record for the selected date, show those habits
  // Otherwise, show the current habits but mark them all as not completed
  const displayHabits = habits.map(habit => {
    if (selectedDateRecord) {
      return {
        ...habit,
        isCompleted: selectedDateRecord.completedHabits.includes(habit.id)
      };
    } else {
      return {
        ...habit,
        isCompleted: false
      };
    }
  });

  // Handlers are mocked for this demo
  const handleAddHabit = (newHabit: Omit<Habit, 'id' | 'userId' | 'createdAt' | 'streak'>) => {
    console.log('Adding habit:', newHabit);
  };

  const handleToggleHabit = (habitId: string) => {
    console.log('Toggling habit:', habitId);
  };

  const handleDeleteHabit = (habitId: string) => {
    console.log('Deleting habit:', habitId);
  };

  return (
    <Layout title="Calendar View">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Calendar (wider on larger screens) */}
        <div className="md:col-span-7 lg:col-span-8">
          <Calendar
            records={records}
            onSelectDate={setSelectedDate}
            selectedDate={selectedDate}
          />
          
          <div className="bg-white dark:bg-gray-800 rounded-xl p-4 mt-6 shadow-sm border border-gray-100 dark:border-gray-700">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Statistics</h3>
            
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="bg-indigo-50 dark:bg-indigo-900/20 rounded-lg p-3 text-center">
                <p className="text-xs text-gray-500 dark:text-gray-400">Completion Rate</p>
                <p className="text-xl font-bold text-indigo-600 dark:text-indigo-400">68%</p>
              </div>
              
              <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-3 text-center">
                <p className="text-xs text-gray-500 dark:text-gray-400">Perfect Days</p>
                <p className="text-xl font-bold text-green-600 dark:text-green-400">12</p>
              </div>
              
              <div className="bg-amber-50 dark:bg-amber-900/20 rounded-lg p-3 text-center">
                <p className="text-xs text-gray-500 dark:text-gray-400">Current Streak</p>
                <p className="text-xl font-bold text-amber-600 dark:text-amber-400">5 days</p>
              </div>
              
              <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3 text-center">
                <p className="text-xs text-gray-500 dark:text-gray-400">Best Streak</p>
                <p className="text-xl font-bold text-blue-600 dark:text-blue-400">14 days</p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Daily Habits for Selected Date */}
        <div className="md:col-span-5 lg:col-span-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm border border-gray-100 dark:border-gray-700 mb-6">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
              {formattedDate}
            </h3>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {selectedDateRecord 
                ? `Completed ${selectedDateRecord.completedHabits.length} of ${selectedDateRecord.totalHabits} habits` 
                : 'No records for this day'}
            </p>
          </div>
          
          <HabitList
            habits={displayHabits}
            loading={loading}
            onAddHabit={handleAddHabit}
            onToggleHabit={handleToggleHabit}
            onDeleteHabit={handleDeleteHabit}
          />
        </div>
      </div>
    </Layout>
  );
};

export default CalendarPage;