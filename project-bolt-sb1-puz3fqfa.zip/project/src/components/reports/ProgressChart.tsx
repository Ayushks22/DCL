import React from 'react';
import { format, subDays } from 'date-fns';
import { DailyRecord } from '../../types';

interface ProgressChartProps {
  records: DailyRecord[];
  days?: number;
}

const ProgressChart: React.FC<ProgressChartProps> = ({ records, days = 7 }) => {
  // Generate dates for the last X days
  const generateDates = () => {
    const dates = [];
    for (let i = days - 1; i >= 0; i--) {
      dates.push(subDays(new Date(), i));
    }
    return dates;
  };

  const dates = generateDates();

  // Map completion data to dates
  const chartData = dates.map(date => {
    const formattedDate = format(date, 'yyyy-MM-dd');
    const record = records.find(r => {
      const recordDate = format(new Date(r.date), 'yyyy-MM-dd');
      return recordDate === formattedDate;
    });

    return {
      date,
      percentage: record 
        ? (record.completedHabits.length / record.totalHabits) * 100 
        : 0,
    };
  });

  // Find the max percentage to scale the chart
  const maxPercentage = Math.max(...chartData.map(d => d.percentage), 100);

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm border border-gray-100 dark:border-gray-700">
      <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
        Your Progress
      </h3>
      
      <div className="flex items-end h-44 space-x-2">
        {chartData.map((data, i) => (
          <div key={i} className="flex-1 flex flex-col items-center">
            <div className="relative w-full flex justify-center mb-1">
              <div
                className="w-full max-w-[30px] bg-indigo-100 dark:bg-indigo-900/30 rounded-t-lg"
                style={{
                  height: `${(data.percentage / 100) * 150}px`,
                  backgroundColor: data.percentage >= 75 
                    ? '#10B981' 
                    : data.percentage >= 50 
                      ? '#6366F1' 
                      : data.percentage > 0 
                        ? '#F59E0B' 
                        : '#E5E7EB',
                }}
              ></div>
              <div className="absolute top-0 mt-1 text-xs font-medium">
                {data.percentage > 0 ? `${Math.round(data.percentage)}%` : ''}
              </div>
            </div>
            <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              {format(data.date, 'E')}
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-2">
            <div className="text-sm font-medium text-gray-500 dark:text-gray-400">
              Streak
            </div>
            <div className="text-xl font-bold text-indigo-600 dark:text-indigo-400">
              {chartData.filter(d => d.percentage > 0).length} days
            </div>
          </div>
          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-2">
            <div className="text-sm font-medium text-gray-500 dark:text-gray-400">
              Average
            </div>
            <div className="text-xl font-bold text-indigo-600 dark:text-indigo-400">
              {Math.round(chartData.reduce((sum, d) => sum + d.percentage, 0) / days)}%
            </div>
          </div>
          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-2">
            <div className="text-sm font-medium text-gray-500 dark:text-gray-400">
              Best Day
            </div>
            <div className="text-xl font-bold text-indigo-600 dark:text-indigo-400">
              {Math.round(Math.max(...chartData.map(d => d.percentage)))}%
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProgressChart;