import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageSquareText, X, Send, Maximize2, Minimize2 } from 'lucide-react';
import { ChatMessage } from '../../types';

const Chatbot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      senderId: 'bot',
      content: "👋 Hi there! I'm your HabitHero assistant. How can I help you with your habits today?",
      timestamp: new Date(),
      isBot: true,
    },
  ]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const toggleOpen = () => {
    setIsOpen(!isOpen);
    setIsMinimized(false);
  };

  const toggleMinimize = () => {
    setIsMinimized(!isMinimized);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!message.trim()) return;
    
    // Add user message
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      senderId: 'user',
      content: message,
      timestamp: new Date(),
      isBot: false,
    };
    
    setMessages([...messages, userMessage]);
    setMessage('');
    
    // Simulate bot response
    setTimeout(() => {
      const botResponses = [
        "I'm here to help you stay consistent with your habits!",
        "Remember, consistency is key to forming good habits.",
        "You're doing great with your habit tracking!",
        "Need some motivation? Try setting a specific time for your habits.",
        "Small steps every day lead to big results over time.",
      ];
      
      const randomResponse = botResponses[Math.floor(Math.random() * botResponses.length)];
      
      const botMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        senderId: 'bot',
        content: randomResponse,
        timestamp: new Date(),
        isBot: true,
      };
      
      setMessages(prev => [...prev, botMessage]);
    }, 1000);
  };

  // Auto scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <>
      {/* Chatbot Button */}
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 1 }}
        className="fixed bottom-6 right-6 z-50"
      >
        <button
          onClick={toggleOpen}
          className="bg-indigo-600 hover:bg-indigo-700 text-white rounded-full p-4 shadow-lg flex items-center justify-center"
        >
          <MessageSquareText className="h-6 w-6" />
        </button>
      </motion.div>

      {/* Chatbot Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ 
              opacity: 1, 
              y: 0, 
              scale: 1,
              height: isMinimized ? 'auto' : '480px',
              width: isMinimized ? '300px' : '360px'
            }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="fixed bottom-20 right-6 bg-white dark:bg-gray-800 rounded-2xl shadow-xl overflow-hidden z-50 flex flex-col"
          >
            {/* Header */}
            <div className="p-4 bg-indigo-600 dark:bg-indigo-700 text-white flex justify-between items-center">
              <div className="flex items-center">
                <MessageSquareText className="h-5 w-5 mr-2" />
                <h3 className="font-medium">HabitHero Assistant</h3>
              </div>
              <div className="flex space-x-2">
                <button 
                  onClick={toggleMinimize}
                  className="p-1 hover:bg-indigo-500 rounded-full transition-colors"
                >
                  {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
                </button>
                <button 
                  onClick={toggleOpen}
                  className="p-1 hover:bg-indigo-500 rounded-full transition-colors"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Messages Area */}
            {!isMinimized && (
              <div className="flex-1 p-4 overflow-y-auto">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`mb-4 flex ${msg.isBot ? 'justify-start' : 'justify-end'}`}
                  >
                    <div
                      className={`max-w-[80%] p-3 rounded-lg ${
                        msg.isBot
                          ? 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-white rounded-tl-none'
                          : 'bg-indigo-500 text-white rounded-tr-none'
                      }`}
                    >
                      <p className="text-sm">{msg.content}</p>
                      <p className="text-xs mt-1 opacity-70">
                        {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
            )}

            {/* Input Area */}
            {!isMinimized && (
              <form onSubmit={handleSendMessage} className="p-3 border-t border-gray-200 dark:border-gray-700 flex">
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Type your message..."
                  className="flex-1 px-4 py-2 bg-gray-100 dark:bg-gray-700 rounded-l-lg text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white rounded-r-lg px-4 py-2 flex items-center justify-center"
                >
                  <Send className="h-5 w-5" />
                </button>
              </form>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Chatbot;