import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Settings, Loader2 } from 'lucide-react';
import HabitItem from './HabitItem';
import HabitForm from './HabitForm';
import { Habit } from '../../types';

interface HabitListProps {
  habits: Habit[];
  loading: boolean;
  onAddHabit: (habit: Omit<Habit, 'id' | 'userId' | 'createdAt' | 'streak'>) => void;
  onToggleHabit: (habitId: string) => void;
  onDeleteHabit: (habitId: string) => void;
}

const HabitList: React.FC<HabitListProps> = ({
  habits,
  loading,
  onAddHabit,
  onToggleHabit,
  onDeleteHabit,
}) => {
  const [isAddingHabit, setIsAddingHabit] = useState(false);

  const handleAddHabit = (newHabit: Omit<Habit, 'id' | 'userId' | 'createdAt' | 'streak'>) => {
    onAddHabit(newHabit);
    setIsAddingHabit(false);
  };

  // Group habits by category
  const groupedHabits: Record<string, Habit[]> = habits.reduce((acc, habit) => {
    const category = habit.category || 'General';
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(habit);
    return acc;
  }, {} as Record<string, Habit[]>);

  const categories = Object.keys(groupedHabits).sort();

  // Calculate completion percentage
  const completedCount = habits.filter(habit => habit.isCompleted).length;
  const totalCount = habits.length;
  const completionPercentage = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  return (
    <div className="bg-gray-50 dark:bg-gray-900 rounded-xl p-4 sm:p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">Daily Habits</h2>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsAddingHabit(true)}
            className="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            <Plus className="h-4 w-4 mr-1" />
            Add Habit
          </button>
          <button className="inline-flex items-center p-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white focus:outline-none">
            <Settings className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Progress bar */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
            Daily progress
          </span>
          <span className="text-sm font-medium text-indigo-600 dark:text-indigo-400">
            {completedCount}/{totalCount} ({completionPercentage}%)
          </span>
        </div>
        <div className="h-3 w-full bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${completionPercentage}%` }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
            className={`h-full ${
              completionPercentage === 100
                ? 'bg-green-500'
                : completionPercentage > 50
                ? 'bg-indigo-500'
                : 'bg-indigo-400'
            }`}
          />
        </div>
      </div>

      {/* Add Habit Form */}
      <AnimatePresence>
        {isAddingHabit && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="mb-6"
          >
            <HabitForm
              onSubmit={handleAddHabit}
              onCancel={() => setIsAddingHabit(false)}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Loading State */}
      {loading && (
        <div className="flex justify-center items-center py-12">
          <Loader2 className="h-8 w-8 text-indigo-500 animate-spin" />
        </div>
      )}

      {/* Empty State */}
      {!loading && habits.length === 0 && (
        <div className="text-center py-12 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-xl">
          <div className="inline-flex items-center justify-center p-4 bg-indigo-100 dark:bg-indigo-900/30 rounded-full mb-4">
            <Plus className="h-8 w-8 text-indigo-600 dark:text-indigo-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No habits yet</h3>
          <p className="text-gray-500 dark:text-gray-400 max-w-sm mx-auto mb-6">
            Start building better habits by adding your first daily habit to track.
          </p>
          <button
            onClick={() => setIsAddingHabit(true)}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
          >
            <Plus className="h-4 w-4 mr-1" />
            Add your first habit
          </button>
        </div>
      )}

      {/* Habits by Category */}
      {!loading && habits.length > 0 && (
        <div className="space-y-6">
          {categories.map(category => (
            <div key={category}>
              <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-3">
                {category}
              </h3>
              <AnimatePresence>
                {groupedHabits[category].map(habit => (
                  <HabitItem
                    key={habit.id}
                    habit={habit}
                    onToggle={onToggleHabit}
                    onDelete={onDeleteHabit}
                  />
                ))}
              </AnimatePresence>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default HabitList;