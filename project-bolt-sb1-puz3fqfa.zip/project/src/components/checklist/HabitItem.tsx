import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2, Circle, Trash2 } from 'lucide-react';
import { Habit } from '../../types';

interface HabitItemProps {
  habit: Habit;
  onToggle: (habitId: string) => void;
  onDelete: (habitId: string) => void;
}

const HabitItem: React.FC<HabitItemProps> = ({ habit, onToggle, onDelete }) => {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, height: 0 }}
      transition={{ duration: 0.2 }}
      className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 mb-3 border border-gray-100 dark:border-gray-700"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3 flex-1">
          <button
            onClick={() => onToggle(habit.id)}
            className={`flex-shrink-0 rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 ${
              habit.isCompleted ? 'text-green-500 hover:text-green-600' : 'text-gray-400 hover:text-gray-500'
            }`}
          >
            {habit.isCompleted ? (
              <CheckCircle2 className="h-6 w-6" />
            ) : (
              <Circle className="h-6 w-6" />
            )}
          </button>
          <div className="flex-1 min-w-0">
            <p
              className={`text-sm font-medium ${
                habit.isCompleted
                  ? 'line-through text-gray-500 dark:text-gray-400'
                  : 'text-gray-900 dark:text-white'
              }`}
            >
              {habit.title}
            </p>
            {habit.description && (
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 truncate">
                {habit.description}
              </p>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <div className="text-xs font-medium px-2 py-1 rounded-full bg-indigo-100 dark:bg-indigo-900/30 text-indigo-800 dark:text-indigo-300">
            {habit.frequency}
          </div>
          {habit.streak > 0 && (
            <div className="text-xs font-medium px-2 py-1 rounded-full bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-300">
              {habit.streak} day{habit.streak > 1 ? 's' : ''}
            </div>
          )}
          <button
            onClick={() => onDelete(habit.id)}
            className="text-gray-400 hover:text-red-500 focus:outline-none"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default HabitItem;