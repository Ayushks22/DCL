import React, { useState } from 'react';
import { format, addMonths, subMonths, startOfMonth, endOfMonth, startOfWeek, endOfWeek, eachDayOfInterval, isSameMonth, isSameDay, isToday } from 'date-fns';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { DailyRecord } from '../../types';

interface CalendarProps {
  records: DailyRecord[];
  onSelectDate: (date: Date) => void;
  selectedDate: Date;
}

const Calendar: React.FC<CalendarProps> = ({ records, onSelectDate, selectedDate }) => {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const prevMonth = () => {
    setCurrentMonth(subMonths(currentMonth, 1));
  };

  const nextMonth = () => {
    setCurrentMonth(addMonths(currentMonth, 1));
  };

  const renderHeader = () => {
    return (
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={prevMonth}
          className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
        >
          <ChevronLeft className="h-5 w-5 text-gray-600 dark:text-gray-300" />
        </button>
        <h2 className="text-lg font-bold text-gray-900 dark:text-white">
          {format(currentMonth, 'MMMM yyyy')}
        </h2>
        <button
          onClick={nextMonth}
          className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
        >
          <ChevronRight className="h-5 w-5 text-gray-600 dark:text-gray-300" />
        </button>
      </div>
    );
  };

  const renderDays = () => {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    return (
      <div className="grid grid-cols-7 mb-1">
        {days.map((day) => (
          <div
            key={day}
            className="py-2 text-center text-sm font-medium text-gray-500 dark:text-gray-400"
          >
            {day}
          </div>
        ))}
      </div>
    );
  };

  const renderCells = () => {
    const monthStart = startOfMonth(currentMonth);
    const monthEnd = endOfMonth(monthStart);
    const startDate = startOfWeek(monthStart);
    const endDate = endOfWeek(monthEnd);

    const dateFormat = 'd';
    const rows = [];
    let days = [];
    let day = startDate;
    let formattedDate = '';

    while (day <= endDate) {
      for (let i = 0; i < 7; i++) {
        formattedDate = format(day, dateFormat);
        
        // Find record for this day
        const record = records.find((r) => isSameDay(new Date(r.date), day));
        const completionRate = record 
          ? (record.completedHabits.length / record.totalHabits) * 100 
          : null;
        
        const isCurrentMonth = isSameMonth(day, monthStart);
        const isSelected = isSameDay(day, selectedDate);
        const isTdy = isToday(day);
        
        days.push(
          <div
            key={day.toString()}
            className={`p-1 border-t border-gray-200 dark:border-gray-700 ${
              i === 0 ? 'border-l' : ''
            } ${i === 6 ? 'border-r' : ''} ${
              !isCurrentMonth ? 'bg-gray-50 dark:bg-gray-800/50' : ''
            }`}
          >
            <button
              className={`w-full flex flex-col items-center justify-center rounded-lg py-2 
                ${isCurrentMonth ? 'text-gray-900 dark:text-white' : 'text-gray-400 dark:text-gray-500'} 
                ${isSelected ? 'bg-indigo-100 dark:bg-indigo-900/30' : ''} 
                ${isTdy && !isSelected ? 'bg-blue-50 dark:bg-blue-900/20' : ''}
                hover:bg-gray-100 dark:hover:bg-gray-700 relative
              `}
              onClick={() => onSelectDate(day)}
            >
              <span className={`text-sm ${isTdy ? 'font-bold' : ''}`}>
                {formattedDate}
              </span>
              
              {completionRate !== null && isCurrentMonth && (
                <div className="mt-1 relative w-4 h-4">
                  <svg viewBox="0 0 36 36" className="w-4 h-4">
                    <path
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      fill="none"
                      stroke={completionRate >= 75 ? '#10B981' : completionRate >= 50 ? '#6366F1' : '#F59E0B'}
                      strokeWidth="3"
                      strokeDasharray={`${completionRate}, 100`}
                    />
                  </svg>
                </div>
              )}
            </button>
          </div>
        );
        day = new Date(day.getTime() + 24 * 60 * 60 * 1000); // Add a day
      }
      
      rows.push(
        <div key={day.toString()} className="grid grid-cols-7">
          {days}
        </div>
      );
      days = [];
    }
    
    return <div className="border-b border-gray-200 dark:border-gray-700">{rows}</div>;
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 border border-gray-100 dark:border-gray-700">
      {renderHeader()}
      {renderDays()}
      {renderCells()}
    </div>
  );
};

export default Calendar;