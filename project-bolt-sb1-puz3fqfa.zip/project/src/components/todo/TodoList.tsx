import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, CheckSquare, Loader2 } from 'lucide-react';
import TodoItem from './TodoItem';
import TodoForm from './TodoForm';
import { Todo } from '../../types';

interface TodoListProps {
  todos: Todo[];
  loading: boolean;
  onAddTodo: (todo: Omit<Todo, 'id' | 'userId' | 'createdAt'>) => void;
  onToggleTodo: (todoId: string) => void;
  onDeleteTodo: (todoId: string) => void;
}

const TodoList: React.FC<TodoListProps> = ({
  todos,
  loading,
  onAddTodo,
  onToggleTodo,
  onDeleteTodo,
}) => {
  const [isAddingTodo, setIsAddingTodo] = useState(false);

  const handleAddTodo = (newTodo: Omit<Todo, 'id' | 'userId' | 'createdAt'>) => {
    onAddTodo(newTodo);
    setIsAddingTodo(false);
  };

  // Filter todos
  const completedTodos = todos.filter(todo => todo.isCompleted);
  const pendingTodos = todos.filter(todo => !todo.isCompleted);

  return (
    <div className="bg-gray-50 dark:bg-gray-900 rounded-xl p-4 sm:p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">To-Do List</h2>
        <button
          onClick={() => setIsAddingTodo(true)}
          className="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          <Plus className="h-4 w-4 mr-1" />
          Add Task
        </button>
      </div>

      {/* Add Todo Form */}
      <AnimatePresence>
        {isAddingTodo && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="mb-6"
          >
            <TodoForm
              onSubmit={handleAddTodo}
              onCancel={() => setIsAddingTodo(false)}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Loading State */}
      {loading && (
        <div className="flex justify-center items-center py-12">
          <Loader2 className="h-8 w-8 text-indigo-500 animate-spin" />
        </div>
      )}

      {/* Empty State */}
      {!loading && todos.length === 0 && (
        <div className="text-center py-12 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-xl">
          <div className="inline-flex items-center justify-center p-4 bg-indigo-100 dark:bg-indigo-900/30 rounded-full mb-4">
            <CheckSquare className="h-8 w-8 text-indigo-600 dark:text-indigo-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No tasks yet</h3>
          <p className="text-gray-500 dark:text-gray-400 max-w-sm mx-auto mb-6">
            Add tasks to your to-do list to keep track of what you need to accomplish today.
          </p>
          <button
            onClick={() => setIsAddingTodo(true)}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
          >
            <Plus className="h-4 w-4 mr-1" />
            Add your first task
          </button>
        </div>
      )}

      {/* Pending Todos */}
      {!loading && pendingTodos.length > 0 && (
        <>
          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-3">
            Pending Tasks ({pendingTodos.length})
          </h3>
          <AnimatePresence>
            {pendingTodos.map(todo => (
              <TodoItem
                key={todo.id}
                todo={todo}
                onToggle={onToggleTodo}
                onDelete={onDeleteTodo}
              />
            ))}
          </AnimatePresence>
        </>
      )}

      {/* Completed Todos */}
      {!loading && completedTodos.length > 0 && (
        <div className="mt-8">
          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-3">
            Completed ({completedTodos.length})
          </h3>
          <AnimatePresence>
            {completedTodos.map(todo => (
              <TodoItem
                key={todo.id}
                todo={todo}
                onToggle={onToggleTodo}
                onDelete={onDeleteTodo}
              />
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
};

export default TodoList;