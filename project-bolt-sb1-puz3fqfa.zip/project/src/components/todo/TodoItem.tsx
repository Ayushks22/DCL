import React from 'react';
import { motion } from 'framer-motion';
import { CheckSquare, Square, Trash2, Clock } from 'lucide-react';
import { Todo } from '../../types';
import { format } from 'date-fns';

interface TodoItemProps {
  todo: Todo;
  onToggle: (todoId: string) => void;
  onDelete: (todoId: string) => void;
}

const TodoItem: React.FC<TodoItemProps> = ({ todo, onToggle, onDelete }) => {
  // Get priority color
  const getPriorityColor = () => {
    switch (todo.priority) {
      case 'high':
        return 'text-red-600 dark:text-red-400 bg-red-100 dark:bg-red-900/20';
      case 'medium':
        return 'text-amber-600 dark:text-amber-400 bg-amber-100 dark:bg-amber-900/20';
      case 'low':
        return 'text-green-600 dark:text-green-400 bg-green-100 dark:bg-green-900/20';
      default:
        return 'text-gray-600 dark:text-gray-400 bg-gray-100 dark:bg-gray-700';
    }
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, height: 0 }}
      transition={{ duration: 0.2 }}
      className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-3 mb-2 border border-gray-100 dark:border-gray-700"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3 flex-1">
          <button
            onClick={() => onToggle(todo.id)}
            className={`flex-shrink-0 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 ${
              todo.isCompleted ? 'text-indigo-500 hover:text-indigo-600' : 'text-gray-400 hover:text-gray-500'
            }`}
          >
            {todo.isCompleted ? (
              <CheckSquare className="h-5 w-5" />
            ) : (
              <Square className="h-5 w-5" />
            )}
          </button>
          <span
            className={`text-sm ${
              todo.isCompleted
                ? 'line-through text-gray-500 dark:text-gray-400'
                : 'text-gray-900 dark:text-white'
            }`}
          >
            {todo.title}
          </span>
        </div>

        <div className="flex items-center space-x-2">
          {todo.dueDate && (
            <div className="text-xs flex items-center space-x-1 text-gray-500 dark:text-gray-400">
              <Clock className="h-3 w-3" />
              <span>{format(new Date(todo.dueDate), 'MMM d')}</span>
            </div>
          )}
          
          <div className={`text-xs font-medium px-2 py-0.5 rounded-full ${getPriorityColor()}`}>
            {todo.priority}
          </div>
          
          <button
            onClick={() => onDelete(todo.id)}
            className="text-gray-400 hover:text-red-500 focus:outline-none"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default TodoItem;