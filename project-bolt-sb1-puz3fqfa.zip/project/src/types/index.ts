export interface User {
  id: string;
  displayName: string | null;
  email: string | null;
  photoURL: string | null;
  phoneNumber: string | null;
}

export interface Habit {
  id: string;
  userId: string;
  title: string;
  description?: string;
  isCompleted: boolean;
  completedAt?: Date;
  createdAt: Date;
  frequency: 'daily' | 'weekly' | 'monthly';
  category?: string;
  streak: number;
}

export interface Todo {
  id: string;
  userId: string;
  title: string;
  isCompleted: boolean;
  dueDate?: Date;
  priority: 'low' | 'medium' | 'high';
  createdAt: Date;
}

export interface DailyRecord {
  id: string;
  userId: string;
  date: Date;
  completedHabits: string[];
  totalHabits: number;
  notes?: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  content: string;
  timestamp: Date;
  isBot: boolean;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  isRead: boolean;
  createdAt: Date;
}